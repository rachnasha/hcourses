package edu.harvard.cscie98.sample_code;

public class Allocation {

  public Allocation(final int arg1, final int arg2) {

  }

  public static void main(final String[] args) {
    new Allocation(1, 2);
  }

}
