package edu.harvard.cscie98.sample_code;

public class HelloWorld {

  public static void main(final String[] args) {
    System.out.println("Hello World");
  }

}
