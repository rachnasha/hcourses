package edu.harvard.cscie98.sample_code;

public class Loop {

  public static void main(final String[] args) {
    int val = 0;
    for (int i = 0; i < 100; i++) {
      val = val + 1;
    }
  }
}
