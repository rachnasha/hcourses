package edu.harvard.cscie98.sample_code;

public class Multiplication {
  public static void main(final String[] args) {
    final int val1 = 4;
    final int val2 = 50;

    int result = 0;
    for (int i = 0; i < val1; i++) {
      result = result + val2;
    }
  }
}
