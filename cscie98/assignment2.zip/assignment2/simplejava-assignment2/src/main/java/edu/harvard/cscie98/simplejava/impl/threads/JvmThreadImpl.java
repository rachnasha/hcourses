package edu.harvard.cscie98.simplejava.impl.threads;

import edu.harvard.cscie98.simplejava.vm.VmInternalError;
import edu.harvard.cscie98.simplejava.vm.threads.JvmStack;
import edu.harvard.cscie98.simplejava.vm.threads.JvmThread;

public class JvmThreadImpl implements JvmThread {

  private final JvmStackImpl stack;
  private boolean paused;

  public JvmThreadImpl() {
    this.stack = new JvmStackImpl();
    this.paused = false;
  }

  @Override
  public JvmStack getStack() {
    return stack;
  }

  @Override
  public void resume() {
    if (!paused) {
      throw new VmInternalError("Thread is not paused");
    }
    paused = false;
  }

  @Override
  public void pause() {
    if (paused) {
      throw new VmInternalError("Thread is already paused");
    }
    paused = true;
  }

}
