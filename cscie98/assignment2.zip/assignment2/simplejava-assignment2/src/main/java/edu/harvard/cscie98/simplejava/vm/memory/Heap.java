package edu.harvard.cscie98.simplejava.vm.memory;

import edu.harvard.cscie98.simplejava.impl.memory.heap.BumpPointerRegion;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public interface Heap {

  BumpPointerRegion getBumpPointerRegion(HeapPointer baseAddress, long extent);

  void memcpy(HeapPointer from, HeapPointer to);

}
