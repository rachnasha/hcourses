package edu.harvard.cscie98.simplejava.impl.interpreter;

import org.apache.bcel.classfile.ConstantFieldref;
import org.apache.bcel.classfile.ConstantMethodref;
import org.apache.bcel.classfile.ConstantNameAndType;

import edu.harvard.cscie98.simplejava.vm.classloader.TypeFactory;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClass;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmConstantPool;
import edu.harvard.cscie98.simplejava.vm.classloader.VmField;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.threads.JvmStack;
import edu.harvard.cscie98.simplejava.vm.threads.StackFrame;

public class InterpreterUtils {

  public static final int getByteImmediate(final byte[] code, final int idx) {
    return code[idx];
  }

  public static final int getByteUnsigned(final byte[] code, final int idx) {
    final byte b = code[idx];
    final int i = b & 0xFF;
    return i;
  }

  public static final int getSignedDoubleByte(final byte[] code, final int idx) {
    final byte one = code[idx];
    final byte two = code[idx + 1];
    int val = one;
    val <<= 8;
    val |= (two & 0xFF);
    return val;
  }

  public static int getUnsignedDoubleByte(final byte[] code, final int idx) {
    final int one = getByteUnsigned(code, idx);
    final int two = getByteUnsigned(code, idx + 1);
    int val = one << 8;
    val |= two;
    return val;
  }

  private static ConstantNameAndType getMethodNameType(final VmConstantPool constantPool,
      final int cpIndex) {
    final ConstantMethodref methodEntry = constantPool.getMethodEntry(cpIndex);
    return constantPool.getNameAndTypeEntry(methodEntry.getNameAndTypeIndex());
  }

  public static String getMethodName(final VmConstantPool constantPool, final int cpIndex) {
    final ConstantNameAndType methodNt = getMethodNameType(constantPool, cpIndex);
    return constantPool.getUtf8Entry(methodNt.getNameIndex());
  }

  public static String getMethodSignature(final VmConstantPool constantPool, final int cpIndex) {
    final ConstantNameAndType methodNt = getMethodNameType(constantPool, cpIndex);
    return constantPool.getUtf8Entry(methodNt.getSignatureIndex());
  }

  public static TypeName getMethodClass(final VmConstantPool constantPool, final int cpIndex) {
    final ConstantMethodref methodEntry = constantPool.getMethodEntry(cpIndex);
    return constantPool.getClassEntry(methodEntry.getClassIndex());
  }

  private static ConstantNameAndType getFieldNameType(final VmConstantPool constantPool,
      final int cpIndex) {
    final ConstantFieldref fieldEntry = constantPool.getFieldEntry(cpIndex);
    return constantPool.getNameAndTypeEntry(fieldEntry.getNameAndTypeIndex());
  }

  public static String getFieldName(final VmConstantPool constantPool, final int cpIndex) {
    final ConstantNameAndType fieldNt = getFieldNameType(constantPool, cpIndex);
    return constantPool.getUtf8Entry(fieldNt.getNameIndex());
  }

  public static TypeName getFieldSignature(final VmConstantPool constantPool, final int cpIndex) {
    final ConstantNameAndType fieldNt = getFieldNameType(constantPool, cpIndex);
    return TypeFactory.fromDescriptor(constantPool.getUtf8Entry(fieldNt.getSignatureIndex()));
  }

  public static TypeName getFieldClass(final VmConstantPool constantPool, final int cpIndex) {
    final ConstantFieldref fieldEntry = constantPool.getFieldEntry(cpIndex);
    return constantPool.getClassEntry(fieldEntry.getClassIndex());
  }

  public static final int getFieldIndex(final int pc, final byte[] code, final StackFrame frame,
      final VmClassLoader classLoader) {
    final VmConstantPool constantPool = frame.getConstantPool();
    final int fieldIdx = InterpreterUtils.getUnsignedDoubleByte(code, pc + 1);
    final TypeName className = InterpreterUtils.getFieldClass(constantPool, fieldIdx);
    VmClass cls = classLoader.loadClass(className);
    final String fieldName = InterpreterUtils.getFieldName(constantPool, fieldIdx);
    final TypeName fieldSignature = InterpreterUtils.getFieldSignature(constantPool, fieldIdx);
    VmField fld = cls.getField(fieldName, fieldSignature);
    while (fld == null) {
      cls = cls.getSuperClass();
      if (cls == null) {
        throw new NoSuchFieldError();
      }
      fld = cls.getField(fieldName, fieldSignature);
    }
    return cls.getObjectTypeDescriptor().getFieldOffset(cls, fld);
  }

  public static Object getOrSetStatic(final int pc, final byte[] code, final StackFrame frame,
      final VmClassLoader classLoader, final Object val) {
    final VmConstantPool constantPool = frame.getConstantPool();
    final int fieldIdx = InterpreterUtils.getUnsignedDoubleByte(code, pc + 1);
    final TypeName className = InterpreterUtils.getFieldClass(constantPool, fieldIdx);
    final String fieldName = InterpreterUtils.getFieldName(constantPool, fieldIdx);
    final TypeName fieldSignature = getFieldSignature(constantPool, fieldIdx);
    final VmClass cls = classLoader.loadClass(className);
    if (val != null) {
      cls.getObjectTypeDescriptor().setStaticField(fieldName, fieldSignature, val);
      return null;
    } else {
      return cls.getObjectTypeDescriptor().getStaticField(fieldName, fieldSignature);
    }
  }

  public static VmMethod getStaticMethodRef(final int pc, final byte[] code,
      final StackFrame frame, final VmClassLoader classLoader) {
    final int methodIdx = InterpreterUtils.getUnsignedDoubleByte(code, pc + 1);
    final VmConstantPool constantPool = frame.getConstantPool();
    final TypeName className = InterpreterUtils.getMethodClass(constantPool, methodIdx);
    final String methodName = InterpreterUtils.getMethodName(constantPool, methodIdx);
    final String methodSig = InterpreterUtils.getMethodSignature(constantPool, methodIdx);
    final VmClass cls = classLoader.loadClass(className);
    return cls.getMethod(methodName, methodSig);
  }

  public static void createStackFrame(final JvmStack stack, final StackFrame frame,
      final VmMethod mthd, final int paramCount) {
    final StackFrame newFrame = stack.push(mthd);
    for (int i = paramCount - 1; i >= 0; i--) {
      newFrame.setLocalVariable(i, frame.pop());
    }
  }

}
