package edu.harvard.cscie98.simplejava.impl.objectmodel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.harvard.cscie98.simplejava.config.HeapParameters;
import edu.harvard.cscie98.simplejava.config.Log;
import edu.harvard.cscie98.simplejava.config.SimpleJavaOutOfScopeException;
import edu.harvard.cscie98.simplejava.impl.memory.heap.HeapImpl;
import edu.harvard.cscie98.simplejava.vm.VmInternalError;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeFactory;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClass;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmField;
import edu.harvard.cscie98.simplejava.vm.memory.MemoryManager;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ArrayTypeDescriptor;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapObject;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectBuilder;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectHeader;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectTypeDescriptor;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ReferenceLocation;

public class ObjectBuilderImpl implements ObjectBuilder {

  private final VmClassLoader classLoader;
  private MemoryManager mm;
  private final HeapImpl heap;
  private final Map<String, HeapObject> internTable;

  public ObjectBuilderImpl(final VmClassLoader classLoader, final HeapImpl heap) {
    this.classLoader = classLoader;
    this.heap = heap;
    internTable = new HashMap<String, HeapObject>();
  }

  public void setMemoryManager(final MemoryManager mm) {
    this.mm = mm;
  }

  @Override
  public HeapObject createArray(final TypeName elementType, final int length) {
    if (elementType.isArray()) {
      throw new SimpleJavaOutOfScopeException("Multidimensional arrays not supported");
    }
    Log.alloc("Creating array of " + elementType + " with size " + length);
    final VmClass cls = classLoader.loadClass(elementType);
    final ArrayTypeDescriptor desc = cls.getArrayTypeDescriptor();
    final long size = (HeapParameters.BYTES_IN_WORD * (length + ObjectHeader.HEADER_SIZE_WORDS));
    final HeapPointer allocated = mm.allocate(size);
    final HeapObject obj = new HeapObjectImpl(allocated, desc, length);
    final Object defaultValue = desc.getTypeName().getDefaultValue();
    for (int i = 0; i < length; i++) {
      obj.setValueAtOffset(i, defaultValue);
    }
    heap.addObject(obj);
    obj.getHeader().setWord(ObjectHeader.ARRAY_LENGTH_WORD, length);
    return obj;
  }

  @Override
  public HeapObject createObject(final TypeName type) {
    if (type.isArray()) {
      throw new VmInternalError("createObject can't be used to create arrays");
    }
    final VmClass cls = classLoader.loadClass(type);
    final ObjectTypeDescriptor desc = cls.getObjectTypeDescriptor();
    final long size = desc.getSize()
        + (ObjectHeader.HEADER_SIZE_WORDS * HeapParameters.BYTES_IN_WORD);
    final HeapPointer allocated = mm.allocate(size);
    final HeapObject obj = new HeapObjectImpl(allocated, desc);
    final List<VmField> fields = desc.getFields();
    for (int i = 0; i < fields.size(); i++) {
      obj.setValueAtOffset(i, fields.get(i).getType().getDefaultValue());
    }
    heap.addObject(obj);
    return obj;
  }

  @Override
  public HeapObject internString(final String str) {
    if (!internTable.containsKey(str)) {
      final HeapObject obj = createObject(TypeFactory.fromBinaryName("java.lang.String"));
      final byte[] bytes = str.getBytes();
      final HeapObject byteArray = createArray(TypeFactory.fromDescriptor("B"), bytes.length);
      for (int i = 0; i < bytes.length; i++) {
        byteArray.setValueAtOffset(i, (int) bytes[i]);
      }
      obj.setValueAtOffset(0, byteArray.getAddress());
      internTable.put(str, obj);
    }
    return internTable.get(str);
  }

  @Override
  public List<ReferenceLocation> getInternTableReferences() {
    final List<ReferenceLocation> refs = new ArrayList<ReferenceLocation>();
    for (final String key : internTable.keySet()) {
      refs.add(new InternTableReferenceLocation(key, internTable));
    }
    return refs;
  }

}
