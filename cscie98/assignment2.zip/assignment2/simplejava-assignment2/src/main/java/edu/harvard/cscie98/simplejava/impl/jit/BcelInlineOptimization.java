package edu.harvard.cscie98.simplejava.impl.jit;

import org.apache.bcel.classfile.Constant;
import org.apache.bcel.generic.ASTORE;
import org.apache.bcel.generic.CPInstruction;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.ISTORE;
import org.apache.bcel.generic.Instruction;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.InstructionList;
import org.apache.bcel.generic.InstructionTargeter;
import org.apache.bcel.generic.InvokeInstruction;
import org.apache.bcel.generic.LocalVariableInstruction;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.TargetLostException;
import org.apache.bcel.generic.Type;

import edu.harvard.cscie98.simplejava.config.Log;
import edu.harvard.cscie98.simplejava.impl.classloader.BcelVmClass;
import edu.harvard.cscie98.simplejava.impl.classloader.BcelVmMethod;
import edu.harvard.cscie98.simplejava.impl.interpreter.InterpreterUtils;
import edu.harvard.cscie98.simplejava.vm.VmInternalError;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClass;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmConstantPool;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.execution.InlineOptimization;

public class BcelInlineOptimization implements InlineOptimization {

  private final VmMethod sourceMethod;
  private VmMethod calledMethod;
  private InstructionHandle callSite;
  private final Integer position;

  private InstructionList sourceInst;
  private InstructionList calledInst;
  private MethodGen sourceGen;
  private MethodGen calledGen;
  private final VmClassLoader classLoader;

  public BcelInlineOptimization(final VmMethod sourceMethod, final Integer position,
      final VmClassLoader classLoader) {
    this.sourceMethod = sourceMethod;
    this.position = position;
    this.classLoader = classLoader;
  }

  public void runOptimization() {
    setUpHandles();

    sourceGen = ((BcelVmMethod) sourceMethod).getMethodGen();
    calledGen = ((BcelVmMethod) calledMethod).getMethodGen();
    Log.jit("Inlining " + calledMethod.getDefiningClass().getName() + "." + calledMethod + " to "
        + sourceMethod.getDefiningClass() + "." + sourceMethod + " at " + callSite.getPosition());

    sourceInst = sourceGen.getInstructionList().copy();
    calledInst = calledGen.getInstructionList().copy();
    InstructionHandle ptr = sourceGen.getInstructionList().getStart();
    InstructionHandle newPtr = sourceInst.getStart();
    InstructionHandle copyHandle = null;
    while (ptr != null) {
      if (ptr == callSite) {
        copyHandle = newPtr;
      }
      ptr = ptr.getNext();
      newPtr = newPtr.getNext();
    }
    if (copyHandle == null) {
      throw new VmInternalError("Didn't find copyHandle");
    }

    updateLocalSlots();
    popInlineMethodParams();
    copyConstantPoolEntries();

    sourceInst.insert(copyHandle, calledInst);
    try {
      final InstructionHandle retInst = copyHandle.getPrev();
      updateInstructionTargeters(retInst, copyHandle.getNext());
      updateInstructionTargeters(copyHandle, copyHandle.getNext());
      sourceInst.delete(retInst);
      sourceInst.delete(copyHandle);
    } catch (final TargetLostException e) {
      throw new VmInternalError(e);
    }
    sourceInst.getByteCode();

    final MethodGen newMethod = new MethodGen(sourceGen.getAccessFlags(),
        sourceGen.getReturnType(), sourceGen.getArgumentTypes(), sourceGen.getArgumentNames(),
        sourceGen.getName(), sourceGen.getClassName(), sourceInst, sourceGen.getConstantPool());
    newMethod.setMaxLocals();
    newMethod.setMaxStack();
    final VmClass cls = sourceMethod.getDefiningClass();
    ((BcelVmClass) cls).replaceMethod(newMethod);
    Log.inliner("Before: \n" + sourceGen.getInstructionList());
    Log.inliner("\nInlining: \n" + calledGen.getInstructionList());
    Log.inliner("\nAfter: \n" + newMethod.getInstructionList());
  }

  private void setUpHandles() {
    sourceGen = ((BcelVmMethod) sourceMethod).getMethodGen();
    sourceInst = sourceGen.getInstructionList();
    final VmConstantPool cp = sourceMethod.getConstantPool();

    for (final InstructionHandle handle : sourceInst.getInstructionHandles()) {
      if (handle.getPosition() == position) {
        callSite = handle;
      }
    }

    final int cpIndex = ((InvokeInstruction) callSite.getInstruction()).getIndex();
    final TypeName cls = InterpreterUtils.getMethodClass(cp, cpIndex);
    final String name = InterpreterUtils.getMethodName(cp, cpIndex);
    final String desc = InterpreterUtils.getMethodSignature(cp, cpIndex);
    final VmClass loadedClass = classLoader.loadClass(cls);

    calledMethod = loadedClass.getMethod(name, desc);
    calledGen = ((BcelVmMethod) calledMethod).getMethodGen();
    calledInst = calledGen.getInstructionList();
  }

  private void copyConstantPoolEntries() {
    if (calledMethod.getDefiningClass().equals(sourceMethod.getDefiningClass())) {
      return;
    }
    final ConstantPoolGen sourceCp = sourceGen.getConstantPool();
    final ConstantPoolGen calledCp = calledGen.getConstantPool();

    for (final InstructionHandle h : calledInst.getInstructionHandles()) {
      final Instruction i = h.getInstruction();
      if (i instanceof CPInstruction) {
        final CPInstruction cpi = (CPInstruction) i;
        final Constant c = calledCp.getConstant(cpi.getIndex());
        final int idx = sourceCp.addConstant(c, calledCp);
        cpi.setIndex(idx);
      }
    }
  }

  private void popInlineMethodParams() {
    final InstructionList pop = new InstructionList();
    final int firstSlot = sourceGen.getMaxLocals();
    int nextSlot = calledGen.isStatic() ? firstSlot : firstSlot + 1;
    for (final Type t : calledGen.getArgumentTypes()) {
      if (t.getSignature().startsWith("[") || t.getSignature().startsWith("L")) {
        pop.append(new ASTORE(nextSlot++));
      } else {
        pop.append(new ISTORE(nextSlot++));
      }
    }
    if (!calledGen.isStatic()) {
      pop.append(new ASTORE(firstSlot));
    }
    calledInst.insert(pop);
  }

  private void updateLocalSlots() {
    final int freeSlot = sourceGen.getMaxLocals();
    for (final InstructionHandle h : calledInst.getInstructionHandles()) {
      final Instruction i = h.getInstruction();
      if (i instanceof LocalVariableInstruction) {
        final LocalVariableInstruction var = (LocalVariableInstruction) i.copy();
        var.setIndex(var.getIndex() + freeSlot);
        h.setInstruction(var);
      }
    }
  }

  private void updateInstructionTargeters(final InstructionHandle handle,
      final InstructionHandle newHandle) {
    if (handle.getTargeters() != null) {
      for (final InstructionTargeter t : handle.getTargeters()) {
        t.updateTarget(handle, newHandle);
      }
    }
  }

  @Override
  public VmMethod getInlinedMethod() {
    return calledMethod;
  }

}
