package edu.harvard.cscie98.simplejava.vm.execution;

import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;

/**
 * This interface represents the compilation engine for the SimpleJava VM. It
 * compiles code at the method level, and it depends on the {@link JitProfiler}
 * to determine which methods should be compiled. The only optimization
 * supported by the SimpleJava JIT is inlining.
 */
public interface JitCompiler {

  /**
   * Register with the JIT compiler that a class has been loaded.
   * 
   * This method is called by the class loader whenever a new class is added to
   * the system. It may trigger a resource-intensive operation if the compiler
   * has to recalculate the Class Hierarchy Analysis.
   */
  void classLoaded();

  /**
   * Register the invocation of a method.
   * 
   * This method is called by the interpreter whenever an InvokeStatic,
   * InvokeVirtual or InvokeSpecial bytecode is executed. It is called before
   * control is transfered to the new method.
   * 
   * This method is expected to be called frequently, and so should not perform
   * significant computation.
   * 
   * @param vmMethod
   *          the {@link VmMethod} that has been invoked.
   */
  void methodCalled(VmMethod vmMethod);

  /**
   * Register that a method invocation has completed.
   * 
   * This method is called by the interpreter when a method returns control to
   * its caller. The compiler may choose to optimize the method that just
   * completed at this point, and so in some cases this call may involve
   * significant computation.
   * 
   * @param method
   *          the {@link VmMethod} that has completed execution.
   */
  void exitMethod(VmMethod method);

}
