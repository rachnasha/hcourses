package edu.harvard.cscie98.simplejava.impl.interpreter.bytecodes;

import java.util.List;

import edu.harvard.cscie98.simplejava.config.Log;
import edu.harvard.cscie98.simplejava.impl.interpreter.InterpreterUtils;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.execution.JitCompiler;
import edu.harvard.cscie98.simplejava.vm.threads.JvmStack;
import edu.harvard.cscie98.simplejava.vm.threads.StackFrame;

public class InvokespecialInst {

  public static void interpret(final int pc, final byte[] code, final JvmStack stack,
      final StackFrame frame, final VmClassLoader classLoader, final JitCompiler jit) {
    final VmMethod mthd = InterpreterUtils.getStaticMethodRef(pc, code, frame, classLoader);
    final List<TypeName> params = mthd.getParamters();
    InterpreterUtils.createStackFrame(stack, frame, mthd, params.size() + 1);
    frame.setProgramCounter(pc + 3);
    jit.methodCalled(mthd);
    // jit.registerMethodInvocation(frame.getVmMethod(),
    // frame.getVmMethod().getCallSiteIdentifier(pc), mthd);
    Log.interpreter("Invoking " + mthd.getDefiningClass() + "." + mthd);
  }
}
