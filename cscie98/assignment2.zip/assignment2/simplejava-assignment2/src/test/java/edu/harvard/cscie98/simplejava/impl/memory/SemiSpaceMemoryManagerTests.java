package edu.harvard.cscie98.simplejava.impl.memory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import edu.harvard.cscie98.simplejava.config.HeapParameters;
import edu.harvard.cscie98.simplejava.impl.memory.heap.BumpPointerRegion;
import edu.harvard.cscie98.simplejava.impl.memory.heap.HeapImpl;
import edu.harvard.cscie98.simplejava.impl.memory.memorymanager.SemiSpaceMemoryManager;
import edu.harvard.cscie98.simplejava.impl.objectmodel.HeapPointerImpl;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ReferenceLocation;
import edu.harvard.cscie98.simplejava.vm.threads.JvmThread;

public class SemiSpaceMemoryManagerTests {

  private SemiSpaceMemoryManager mm;
  private HeapParameters heapParams;
  private HeapImpl heap;
  private JvmThread thread;
  private HeapPointer base;

  @Before
  public void setUp() {
    heap = new HeapImpl();
    base = new HeapPointerImpl(0x1000L, heap);
    heapParams = new HeapParameters(0x1000L, 0x2000L, heap);
    thread = mock(JvmThread.class);
    // XXX Need object manager and classloader.
    mm = new SemiSpaceMemoryManager(heapParams, thread, null, null);
  }

  @Test
  public void testAllocation() {
    final HeapPointer ptr = mm.allocate(10);
    assertNotNull(ptr);
  }

  @Test(expected = RuntimeException.class)
  public void testAllocationOfZeroSizeObject() {
    mm.allocate(0);
  }

  @Test
  public void testSuccessiveAllocationsToDifferentAddresses() {
    final HeapPointer ptr1 = mm.allocate(10);
    final HeapPointer ptr2 = mm.allocate(10);
    assertNotNull(ptr1);
    assertNotNull(ptr1);
    assertTrue(!ptr1.equals(ptr2));
  }

  @SuppressWarnings("unchecked")
  private List<BumpPointerRegion> getRegions() {
    final Class<HeapImpl> cls = HeapImpl.class;
    try {
      final Field fld = cls.getDeclaredField("regions");
      fld.setAccessible(true);
      return (List<BumpPointerRegion>) fld.get(heap);
    } catch (final Exception e) {
      throw new RuntimeException(e);
    }
  }

  private long getRegionExtent(final BumpPointerRegion region) {
    final Class<BumpPointerRegion> cls = BumpPointerRegion.class;
    try {
      final Field fld = cls.getDeclaredField("extent");
      fld.setAccessible(true);
      return (long) fld.get(region);
    } catch (final Exception e) {
      throw new RuntimeException(e);
    }
  }

  private HeapPointer getRegionBase(final BumpPointerRegion region) {
    final Class<BumpPointerRegion> cls = BumpPointerRegion.class;
    try {
      final Field fld = cls.getDeclaredField("baseAddress");
      fld.setAccessible(true);
      return (HeapPointer) fld.get(region);
    } catch (final Exception e) {
      throw new RuntimeException(e);
    }
  }

  @Test
  public void createTwoRegions() {
    assertEquals(2, getRegions().size());
  }

  @Test
  public void bothRegionsHalfOfExtent() {
    for (final BumpPointerRegion region : getRegions()) {
      assertEquals(heapParams.getExtent() / 2, getRegionExtent(region));
    }
  }

  @Test
  public void secondRegionStartAfterFirst() {
    final HeapPointer firstLimit = heapParams.getBaseAddress().add(heapParams.getExtent() / 2);
    assertEquals(firstLimit, getRegionBase(getRegions().get(1)));
  }

  @Test
  public void firstRegionStartAtBase() {
    assertEquals(heapParams.getBaseAddress(), getRegionBase(getRegions().get(0)));
  }

  @Test
  public void checkFirstAllocationToLowestRegion() {
    final HeapPointer ptr = mm.allocate(10);
    assertEquals(heapParams.getBaseAddress(), ptr);
  }

  private void fillAreaWithNoLiveObjects(final long extent) {
    for (int i = 0; i < extent / 2; i += 32) {
      mm.allocate(32);
    }
  }

  @Test
  public void triggerSingleGc() {
    fillAreaWithNoLiveObjects(heapParams.getExtent());
    final HeapPointer ptr = mm.allocate(32);
    assertTrue(!ptr.equals(HeapPointer.NULL));
  }

  @Test
  public void stopThreadBeforeGc() {
    fillAreaWithNoLiveObjects(heapParams.getExtent());
    verify(thread, never()).pause();
    mm.allocate(32);
    verify(thread, times(1)).pause();
  }

  @Test
  public void resumeThreadAfterGc() {
    fillAreaWithNoLiveObjects(heapParams.getExtent());
    verify(thread, never()).resume();
    mm.allocate(32);
    verify(thread, times(1)).resume();
  }

  @Test
  public void copyLiveRoots() {
    fillAreaWithNoLiveObjects(heapParams.getExtent());
    final ReferenceLocation loc = mock(ReferenceLocation.class);
    when(loc.getValue()).thenReturn(base.add(64));
    mm.allocate(32);
    // Put marker field in object @64
    // Mock memcpy call
    // Check semispace 2 for object
  }

  @Test
  public void dontCopyNullReferenceLocation() {

  }

  // Test that there are no Java 'null' values on the heap.
  // Test that the to-space has no pointers in the descriptor header word.
  // Test that there are no to-space pointers on the stack.
  // Test that the intern table has been updated.
  // Test that statics have been updated.
  // Check that from space is reset before the next collection.
}
