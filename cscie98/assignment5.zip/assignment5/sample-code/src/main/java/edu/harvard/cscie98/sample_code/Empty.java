package edu.harvard.cscie98.sample_code;

public class Empty {

  public static void main(final String[] args) {

  }

}
