package edu.harvard.cscie98.simplejava.impl.memory.heap;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class HeapTests {

  // private HeapImpl heap;
  // private ObjectTypeDescriptor objDesc;
  // private ArrayTypeDescriptor arrDesc;
  // private HeapObjectImpl fromObj;
  // private HeapPointerImpl fromPtr;
  // private HeapPointerImpl toPtr;
  // private List<VmField> objFields;

  @Before
  public void setUp() {
    // heap = new HeapImpl();
    // objFields = new ArrayList<VmField>();
    // objDesc = mock(ObjectTypeDescriptor.class);
    // arrDesc = mock(ArrayTypeDescriptor.class);
    // fromPtr = new HeapPointerImpl(0x1000, heap);
    // fromObj = new HeapObjectImpl(fromPtr, objDesc);
    // heap.addObject(fromObj);
    // toPtr = new HeapPointerImpl(0x2000, heap);
  }

  @Test
  @Ignore
  public void memcpyObjectFields() {
  }

  @Test
  @Ignore
  public void memcpyObjectAddedToHeap() {
  }

  @Test
  @Ignore
  public void memcpyObjectTypeDescriptor() {
  }

  @Test
  @Ignore
  public void memcpyArraySize() {
  }

  @Test
  @Ignore
  public void memcpyArrayFields() {
  }

  @Test
  @Ignore
  public void memcpyArrayAddedToHeap() {
  }

  @Test
  @Ignore
  public void memcpyArrayTypeDescriptor() {
  }

  @Test
  @Ignore
  public void memcopyArrayLength() {
  }

}
