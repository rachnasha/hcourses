package edu.harvard.cscie98.simplejava.impl.interpreter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.apache.bcel.Constants;
import org.junit.Before;
import org.junit.Test;

import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapObject;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public class PutfieldBytecodeTest extends BytecodeTest {

  private Object val;
  private HeapPointer ref;
  private HeapObject obj;

  @Override
  @Before
  public void setUp() {
    super.setUp();
    val = new Object();
    ref = getRefWithFieldInCp(5);
    obj = ref.dereference();
    when(obj.getValueAtOffset(5)).thenReturn(val);
    frame.push(ref);
    frame.push(val);
  }

  @Override
  protected int getMaxStack() {
    return 2;
  }

  @Override
  protected int getMaxLocals() {
    return 0;
  }

  @Override
  protected byte[] getBytes() {
    return new byte[] { (byte) Constants.PUTFIELD, 0, 8 };
  }

  @Test
  public void testStackLayout() {
    interpreter.interpretBytecode(frame);
    assertEquals(0, frame.getStack().size());
  }

  @Test
  public void testFieldSet() {
    interpreter.interpretBytecode(frame);
    verify(obj).setValueAtOffset(5, val);
  }

  @Test
  public void testProgramCounter() {
    interpreter.interpretBytecode(frame);
    assertEquals(3, frame.getProgramCounter());
  }

}
