package edu.harvard.cscie98.simplejava.impl.memory.memorymanager;

import edu.harvard.cscie98.simplejava.config.HeapParameters;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.memory.MemoryManager;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectBuilder;
import edu.harvard.cscie98.simplejava.vm.threads.JvmThread;

public class MarkSweepMemoryManager implements MemoryManager {

  public MarkSweepMemoryManager(final HeapParameters heapParams, final JvmThread thread,
      final ObjectBuilder objectBuilder, final VmClassLoader classLoader) {
  }

  @Override
  public HeapPointer allocate(final long bytes) {
    throw new RuntimeException("Unimplemented");
  }

  @Override
  public void garbageCollect() {
    throw new RuntimeException("Unimplemented");
  }
}
