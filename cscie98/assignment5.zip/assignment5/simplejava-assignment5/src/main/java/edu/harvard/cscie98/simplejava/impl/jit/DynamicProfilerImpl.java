package edu.harvard.cscie98.simplejava.impl.jit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import edu.harvard.cscie98.simplejava.config.Log;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClass;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.execution.DynamicProfiler;
import edu.harvard.cscie98.simplejava.vm.execution.InlineOptimization;

public class DynamicProfilerImpl implements DynamicProfiler {

  private final Map<VmMethod, Integer> methodCallCount;
  private final Map<VmMethod, Set<InlineOptimization>> compiledMethods;
  private int callThreshold;
  private Map<VmClass, Map<String, Boolean>> inlineTable;

  public DynamicProfilerImpl() {
    this.methodCallCount = new HashMap<VmMethod, Integer>();
    this.compiledMethods = new HashMap<VmMethod, Set<InlineOptimization>>();
  }

  @Override
  public void methodCalled(final VmMethod mthd) {
    Log.jit("Registering call of " + mthd.getDefiningClass().getName() + "." + mthd);
    if (!methodCallCount.containsKey(mthd)) {
      methodCallCount.put(mthd, 0);
    }
    final int calls = methodCallCount.get(mthd) + 1;
    methodCallCount.put(mthd, calls);
  }

  @Override
  public boolean shouldCompileMethod(final VmMethod mthd) {
    final Integer calls = methodCallCount.get(mthd);
    Log.jit("Method " + mthd.getDefiningClass().getName() + "." + mthd + " called " + calls
        + " times");
    return (calls != null && calls >= callThreshold);
  }

  @Override
  public void methodCompiled(final VmMethod mthd, final Set<InlineOptimization> optimizations) {
    Log.jit("Registering compilation of method " + mthd.getDefiningClass().getName() + "." + mthd);
    compiledMethods.put(mthd, optimizations);
  }

  @Override
  public void analyzeClassHierarchy(final VmClassLoader classLoader) {
    final Map<VmClass, Set<VmClass>> subClasses = calculateSubClassMap(classLoader);
    calculateInlineTable(classLoader, subClasses);
    Log.jit("Analyzed class hierarchy");
  }

  private Map<VmClass, Set<VmClass>> calculateSubClassMap(final VmClassLoader classLoader) {
    final Map<VmClass, Set<VmClass>> subClasses = new HashMap<VmClass, Set<VmClass>>();
    for (final VmClass cls : classLoader.getLoadedClasses()) {
      subClasses.put(cls, new HashSet<VmClass>());
    }
    for (final VmClass cls : classLoader.getLoadedClasses()) {
      VmClass spr = cls.getSuperClass();
      while (spr != null) {
        subClasses.get(spr).add(cls);
        spr = spr.getSuperClass();
      }
    }
    return subClasses;
  }

  private void calculateInlineTable(final VmClassLoader classLoader,
      final Map<VmClass, Set<VmClass>> subClasses) {
    inlineTable = new HashMap<VmClass, Map<String, Boolean>>();
    for (final VmClass cls : classLoader.getLoadedClasses()) {
      inlineTable.put(cls, new HashMap<String, Boolean>());
      for (final VmMethod mthd : cls.getMethods()) {
        boolean safeToInline = true;
        if (!(mthd.isStatic() || (mthd.getName().equals("<init>")))) {
          for (final VmClass sub : subClasses.get(cls)) {
            if (sub.getMethod(mthd.getName(), mthd.getSignature()) != null) {
              safeToInline = false;
            }
          }
        }
        inlineTable.get(cls).put(getInlineTableKey(mthd), safeToInline);
      }
    }

  }

  private String getInlineTableKey(final VmMethod mthd) {
    return mthd.getName() + mthd.getSignature();
  }

  @Override
  public Set<VmMethod> getMethodsWithInvalidOptimizations() {
    final Set<VmMethod> invalid = new HashSet<VmMethod>();
    for (final VmMethod mthd : compiledMethods.keySet()) {
      for (final InlineOptimization op : compiledMethods.get(mthd)) {
        if (!canInline(op.getInlinedMethod())) {
          invalid.add(mthd);
          Log.jit("Method " + mthd + " is invalid");
        }
      }
    }
    int setSize;
    do {
      setSize = invalid.size();
      for (final VmMethod mthd : compiledMethods.keySet()) {
        for (final InlineOptimization op : compiledMethods.get(mthd)) {
          if (invalid.contains(op.getInlinedMethod())) {
            invalid.add(mthd);
            Log.jit("Method " + mthd + " is transitively invalid");
          }
        }
      }
    } while (invalid.size() != setSize);
    Log.jit("Invalid optimizations: " + invalid.size());
    return invalid;
  }

  @Override
  public boolean canInline(final VmMethod mthd) {
    final VmClass cls = mthd.getDefiningClass();
    final String inlineKey = getInlineTableKey(mthd);
    final boolean safeToInline = inlineTable.get(cls).get(inlineKey);
    Log.jit("Checking if method " + cls.getName() + "." + mthd + " can be inlined: " + safeToInline);
    return safeToInline;
  }

  @Override
  public void setCompilationThreshold(final int threshold) {
    this.callThreshold = threshold;
  }
}
