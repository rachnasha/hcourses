package edu.harvard.cscie98.simplejava.impl.interpreter.bytecodes;

import edu.harvard.cscie98.simplejava.impl.interpreter.InterpreterUtils;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeFactory;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectBuilder;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectHeader;
import edu.harvard.cscie98.simplejava.vm.threads.JvmStack;
import edu.harvard.cscie98.simplejava.vm.threads.StackFrame;

public class IaloadInst {

  public static void interpret(final int pc, final byte[] code, final JvmStack stack,
      final StackFrame frame, final ObjectBuilder objectBuilder) {
    final int index = (int) frame.pop();
    final HeapPointer arrayRef = (HeapPointer) frame.pop();

    if (arrayRef == HeapPointer.NULL) {
      final TypeName exceptionName = TypeFactory.fromBinaryName("java.lang.NullPointerException");
      InterpreterUtils.throwException(exceptionName, stack, frame, pc, objectBuilder);
      return;
    }
    final int length = (int) arrayRef.dereference().getHeader()
        .getWord(ObjectHeader.ARRAY_LENGTH_WORD);
    if (index >= length) {
      final TypeName exceptionName = TypeFactory
          .fromBinaryName("java.lang.ArrayIndexOutOfBoundsException");
      InterpreterUtils.throwException(exceptionName, stack, frame, pc, objectBuilder);
      return;
    }

    final int value = (int) arrayRef.dereference().getValueAtOffset(index);
    frame.push(value);
    frame.setProgramCounter(pc + 1);
  }
}
