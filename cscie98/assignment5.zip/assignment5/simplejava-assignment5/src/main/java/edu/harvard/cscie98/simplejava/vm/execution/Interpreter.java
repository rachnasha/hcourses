package edu.harvard.cscie98.simplejava.vm.execution;

import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.threads.JvmThread;
import edu.harvard.cscie98.simplejava.vm.threads.StackFrame;

public interface Interpreter {

  /**
   * Execute the given method using the current thread.
   * <P>
   * This method will execute the instructions of the given method, including
   * any additional methods called by those instructions. It will return either
   * once the outermost method (ie, the method passed in) returns or if an
   * uncaught exception escapes the method's scope.
   * 
   * @param mthd
   *          The method to execute.
   * @param args
   *          An ordered list of argument values to be passed to the method.
   * @return The {@link StackFrame} representing the executed method, containing
   *         the state that it held on exiting the method.
   */
  StackFrame executeMethod(VmMethod mthd, Object... args);

  /**
   * Get the thread associated with this execution engine.
   * <P>
   * Note that in the current implementation there is always exactly one
   * {@code JvmThread}.
   * 
   * @return The {@code JvmThread} managed by this {@code ExecutionEngine}.
   */
  JvmThread getThread();

  /**
   * Print the count of each instruction interpreted during the program's run.
   * 
   * The VM must be run using the -verboseStats option for this method to output
   * anything.
   */
  void printStats();

}
