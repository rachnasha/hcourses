package edu.harvard.cscie98.simplejava.impl.jit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.InvokeInstruction;
import org.apache.bcel.generic.MethodGen;

import edu.harvard.cscie98.simplejava.config.Log;
import edu.harvard.cscie98.simplejava.impl.classloader.BcelVmClass;
import edu.harvard.cscie98.simplejava.impl.classloader.BcelVmMethod;
import edu.harvard.cscie98.simplejava.impl.interpreter.InterpreterUtils;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClass;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmConstantPool;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.execution.DynamicProfiler;
import edu.harvard.cscie98.simplejava.vm.execution.InlineOptimization;
import edu.harvard.cscie98.simplejava.vm.execution.JitCompiler;

public class JitCompilerImpl implements JitCompiler {
  private final DynamicProfiler profiler;
  private final Set<VmMethod> compiledMethods;
  private final Map<VmMethod, VmMethod> originalMethods;
  private final VmClassLoader cl;
  private final List<InlineOptimization> allOptimizations;

  public JitCompilerImpl(final DynamicProfiler profiler, final VmClassLoader cl) {
    this.cl = cl;
    this.compiledMethods = new HashSet<VmMethod>();
    this.originalMethods = new HashMap<VmMethod, VmMethod>();
    this.allOptimizations = new ArrayList<InlineOptimization>();
    this.profiler = profiler;
  }

  @Override
  public void classLoaded() {
    profiler.analyzeClassHierarchy(cl);
    final Set<VmMethod> invalid = profiler.getMethodsWithInvalidOptimizations();
    for (final VmMethod mthd : invalid) {
      decompileMethod(mthd);
    }
    for (final VmMethod mthd : invalid) {
      compileMethod(mthd);
    }
  }

  @Override
  public void exitMethod(final VmMethod method) {
    if (method.getDefiningClass() != null) {
      if (!compiledMethods.contains(method)) {
        if (profiler.shouldCompileMethod(method)) {
          Log.jit("Optimizing " + method.getDefiningClass().getName() + "." + method);
          compileMethod(method);
        }
      }
    }
  }

  @Override
  public void methodCalled(final VmMethod vmMethod) {
    profiler.methodCalled(vmMethod);
  }

  private void decompileMethod(final VmMethod method) {
    Log.jit("Decompiling " + method);
    final VmMethod original = originalMethods.get(method);
    final VmClass cls = original.getDefiningClass();
    ((BcelVmClass) cls).replaceMethod(((BcelVmMethod) original).getMethodGen());
  }

  private void compileMethod(final VmMethod method) {
    originalMethods.put(method, method);
    compiledMethods.add(method);
    final Set<InlineOptimization> optimizations = new HashSet<InlineOptimization>();
    optimizations.addAll(inlinePass(method));
    profiler.methodCompiled(method, optimizations);
  }

  private Set<BcelInlineOptimization> inlinePass(final VmMethod method) {
    final Set<BcelInlineOptimization> optimizations = new HashSet<BcelInlineOptimization>();
    final MethodGen mthd = ((BcelVmMethod) method).getMethodGen();
    final VmConstantPool cp = method.getConstantPool();
    final List<Integer> inlinePositions = new ArrayList<Integer>();
    for (final InstructionHandle handle : mthd.getInstructionList().getInstructionHandles()) {
      if (handle.getInstruction() instanceof InvokeInstruction) {
        final InvokeInstruction iv = (InvokeInstruction) handle.getInstruction();
        final VmMethod vmMthd = getMethodFromInstruction(iv, cp);
        if ((!vmMthd.equals(method)) && profiler.canInline(vmMthd)) {
          inlinePositions.add(handle.getPosition());
        }
      }
    }
    Collections.reverse(inlinePositions);
    for (final Integer position : inlinePositions) {
      final VmMethod tmpMthd = method.getDefiningClass().getMethod(method.getName(),
          method.getSignature());
      final BcelInlineOptimization op = new BcelInlineOptimization(tmpMthd, position, cl);
      op.runOptimization();
      optimizations.add(op);
      allOptimizations.add(op);
    }
    return optimizations;
  }

  private VmMethod getMethodFromInstruction(final InvokeInstruction inst, final VmConstantPool cp) {
    final int cpIndex = inst.getIndex();
    final TypeName cls = InterpreterUtils.getMethodClass(cp, cpIndex);
    final String name = InterpreterUtils.getMethodName(cp, cpIndex);
    final String desc = InterpreterUtils.getMethodSignature(cp, cpIndex);
    final VmClass loadedClass = cl.loadClass(cls);
    return loadedClass.getMethod(name, desc);
  }

  public List<InlineOptimization> getAllOptimizations() {
    return allOptimizations;
  }
}
