package edu.harvard.cscie98.simplejava.impl.memory.memorymanager;

import edu.harvard.cscie98.simplejava.config.HeapParameters;
import edu.harvard.cscie98.simplejava.vm.memory.MemoryManager;
import edu.harvard.cscie98.simplejava.vm.memory.Region;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public class InfiniteMemoryManager implements MemoryManager {

  private final Region region;

  public InfiniteMemoryManager(final HeapParameters heapParams) {
    region = heapParams.getHeap().getBumpPointerRegion(heapParams.getBaseAddress(),
        HeapParameters.BYTES_IN_GB);
  }

  @Override
  public HeapPointer allocate(final long bytes) {
    final HeapPointer allocated = region.allocate(bytes);
    if (allocated == HeapPointer.NULL) {
      System.err.println("Out of memory");
      System.exit(1);
    }
    return allocated;
  }

  @Override
  public void garbageCollect() {
  }

}
