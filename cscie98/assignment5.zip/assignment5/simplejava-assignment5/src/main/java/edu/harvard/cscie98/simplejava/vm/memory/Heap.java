package edu.harvard.cscie98.simplejava.vm.memory;

import edu.harvard.cscie98.simplejava.impl.memory.heap.BumpPointerRegion;
import edu.harvard.cscie98.simplejava.impl.memory.heap.NonContiguousRegion;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public interface Heap {

  /**
   * Create a new bump pointer region in the heap.
   * 
   * A region is a contiguous area of memory set aside on the heap to be managed
   * independently. This method reserves a region of memory to be allocated
   * using a bump pointer allocator.
   * 
   * The region of memory defined by the baseAddress and extent parameters must
   * not overlap with any other regions.
   * 
   * @param baseAddress
   *          A {@code HeapPointer} that refers to the address at which this
   *          memory region will start.
   * @param extent
   *          The number of bytes to be assigned to the region.
   * 
   * @return A new {@link BumpPointerRegion} that is configured to allocate
   *         memory to the address range specified by the parameters.
   */
  BumpPointerRegion getBumpPointerRegion(HeapPointer baseAddress, long extent);

  /**
   * Create a new non-contiguous region in the heap.
   * 
   * A region is a contiguous area of memory set aside on the heap to be managed
   * independently. This method reserves a region of memory to be allocated
   * using a first-fit allocation strategy.
   * 
   * The region of memory defined by the baseAddress and extent parameters must
   * not overlap with any other regions.
   * 
   * @param baseAddress
   *          A {@code HeapPointer} that refers to the address at which this
   *          memory region will start.
   * @param extent
   *          The number of bytes to be assigned to the region.
   * 
   * @return A new {@link NonContiguousRegion} that is configured to allocate
   *         memory to the address range specified by the parameters.
   */
  NonContiguousRegion getNonContiguousRegion(HeapPointer baseAddress, long extent);

  /**
   * Copy an object from one location in the heap to another.
   * 
   * This method performs a shallow copy of the object; it copies all values and
   * pointers found in the header and fields of the objects, but does not copy
   * the objects to which any pointers refer.
   * 
   * @param from
   *          A {@link HeapPointer} that indicates the object to be copied. The
   *          pointer must refer to the start of an object.
   * @param to
   *          A location in memory to which the object will be copied.
   */
  void memcpy(HeapPointer from, HeapPointer to);

}
