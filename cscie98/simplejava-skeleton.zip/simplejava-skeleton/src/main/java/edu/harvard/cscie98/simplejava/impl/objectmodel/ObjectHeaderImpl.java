package edu.harvard.cscie98.simplejava.impl.objectmodel;

import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectHeader;

public class ObjectHeaderImpl implements ObjectHeader {

  private final Object[] words;

  public ObjectHeaderImpl() {
    words = new Object[HEADER_SIZE_WORDS];
  }

  @Override
  public Object getWord(final int idx) {
    return words[idx];
  }

  @Override
  public void setWord(final int idx, final Object val) {
    words[idx] = val;
  }

}
