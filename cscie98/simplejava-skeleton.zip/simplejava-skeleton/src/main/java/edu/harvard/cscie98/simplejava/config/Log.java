package edu.harvard.cscie98.simplejava.config;

public class Log {
  public static boolean LOG_ALLOCATION = false;
  public static boolean LOG_CLASS_LOADING = false;
  public static boolean LOG_GC = true;
  public static boolean LOG_INTERPRETER = false;

  public static void cl(final String msg) {
    if (LOG_CLASS_LOADING) {
      System.out.println("[classloading] " + msg);
    }
  }

  public static void interpreter(final String msg) {
    if (LOG_INTERPRETER) {
      System.out.println("[interpreter]  " + msg);
    }
  }

  public static void alloc(final String msg) {
    if (LOG_ALLOCATION) {
      System.out.println("[allocation]   " + msg);
    }
  }

  public static void gc(final String msg) {
    if (LOG_GC) {
      System.out.println("[collection]   " + msg);
    }
  }

}
