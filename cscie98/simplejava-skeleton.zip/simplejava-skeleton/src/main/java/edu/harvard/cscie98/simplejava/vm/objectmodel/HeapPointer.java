package edu.harvard.cscie98.simplejava.vm.objectmodel;

import edu.harvard.cscie98.simplejava.impl.objectmodel.HeapPointerImpl;

public interface HeapPointer extends Comparable<HeapPointer> {

  /**
   * A singleton representing the null pointer. This implementation assumes that
   * the heap address range never starts at zero.
   */
  public static final HeapPointer NULL = new HeapPointerImpl(0L, null);

  /**
   * Create a new heap pointer at a fixed offset from this pointer.
   * 
   * @param extent
   *          The number of bytes to offset from this pointer.
   * 
   * @return a new {@code HeapPointer} obtained by adding the {@code extent} to
   *         the address of this pointer.
   */
  HeapPointer add(long extent);

  /**
   * Get the {@link HeapObject} referred to by this {@code HeapPointer}
   * 
   * @return The {@code HeapObject} that this {@code HeapPointer} refers to.
   * 
   * @throws RuntimeException
   *           if this HeapPointer does not point to a valid {@code HeapObject}
   */
  HeapObject dereference();

}
