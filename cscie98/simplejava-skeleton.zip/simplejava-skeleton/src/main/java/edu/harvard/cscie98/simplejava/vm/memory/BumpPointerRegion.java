package edu.harvard.cscie98.simplejava.vm.memory;

public interface BumpPointerRegion extends Region {

}
