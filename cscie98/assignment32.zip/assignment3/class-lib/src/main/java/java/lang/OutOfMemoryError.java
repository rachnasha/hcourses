package java.lang;

public class OutOfMemoryError extends RuntimeException {
  public OutOfMemoryError() {
    type = "java.lang.OutOfMemoryError";
  }
}
