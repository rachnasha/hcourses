package edu.harvard.cscie98.simplejava.vm.classloader;

public interface VmExceptionHandler {

  // The start_pc is inclusive and end_pc is exclusive; that is, the exception
  // handler must be active while the program counter is within the interval
  // [start_pc, end_pc).
  int getStartPc();

  int getEndPc();

  TypeName getCatchType();

  int getHandlerPc();

}
