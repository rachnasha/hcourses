package edu.harvard.cscie98.simplejava.config;

import edu.harvard.cscie98.simplejava.impl.memory.heap.HeapImpl;
import edu.harvard.cscie98.simplejava.impl.objectmodel.HeapPointerImpl;
import edu.harvard.cscie98.simplejava.vm.memory.Heap;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public class HeapParameters {

  public static final long BYTES_IN_KB = 1024;
  public static final long BYTES_IN_MB = 1024 * 1024;
  public static final long BYTES_IN_GB = 1024 * 1024 * 1024;
  public static final long BYTES_IN_WORD = 8;

  private final long extent;
  private final Heap heap;
  private final long base;

  public HeapParameters(final long base, final long extent, final Heap heap) {
    this.base = base;
    this.extent = extent;
    this.heap = heap;
  }

  public long getExtent() {
    return extent;
  }

  public HeapPointer getBaseAddress() {
    return new HeapPointerImpl(base, (HeapImpl) heap);
  }

  @Override
  public String toString() {
    return "Base: " + getBaseAddress() + " extent: 0x" + Long.toHexString(extent) + " end: "
        + getBaseAddress().add(extent);
  }

  public Heap getHeap() {
    return heap;
  }
}
