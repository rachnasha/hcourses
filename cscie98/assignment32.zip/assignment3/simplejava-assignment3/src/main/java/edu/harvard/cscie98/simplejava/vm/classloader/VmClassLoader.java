package edu.harvard.cscie98.simplejava.vm.classloader;

import java.util.List;
import java.util.Set;

import edu.harvard.cscie98.simplejava.vm.execution.Interpreter;
import edu.harvard.cscie98.simplejava.vm.execution.JitCompiler;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ReferenceLocation;

public interface VmClassLoader {

  /**
   * Set the interpreter or compiler that will execute code loaded by this class
   * loader
   * 
   * @param execution
   *          an {@link Interpreter} instance.
   */
  void setExecutionEngine(Interpreter execution);

  /**
   * Set the JIT compiler that will make compilation decisions based on class
   * loading events.
   * 
   * @param jit
   *          a {@link JitCompiler} instance.
   */
  void setJitCompiler(JitCompiler jit);

  /**
   * Read and parse a class file from the VM's class path.
   * <P>
   * This method will invoke the {@link Interpreter} associated with the class
   * loader to run any static initializer ({@code <clinit>}) method declared in
   * the class.
   * 
   * @param typeName
   *          the name of the class to be loaded.
   * 
   * @return a {@link VmClass} instance that contains the parsed class file.
   * 
   * @throws RuntimeException
   *           if an error occurs during parsing.
   */
  VmClass loadClass(TypeName typeName);

  /**
   * Get the locations of all reference types contained in static variables
   * loaded by this class loader.
   * <P>
   * This method scans all {@code VmClass} objects loaded by this class loader
   * and creates {@link ReferenceLocation} objects for any reference typed
   * static variables. The variables pointed to by the {@code ReferenceLocation}
   * objects may be {@link HeapPointer#NULL}.
   * 
   * @return a {@code List} of all reference locations found in static
   *         variables.
   */
  List<ReferenceLocation> getStaticReferenceLocations();

  /**
   * Get all classes that have been loaded by this class loader
   * 
   * @return a {@code Set} of {@code VmClass} objects containing all classes
   *         loaded by this class loader.
   */
  Set<VmClass> getLoadedClasses();

}
