package edu.harvard.cscie98.simplejava.vm.execution;

import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;

/**
 * Instances of this interface represent a single optimization. A given
 * optimization pass may generate multiple {@code InlineOptimization} instances.
 * 
 */
public interface InlineOptimization {

  /**
   * Get the method that has been inlined as part of this optimization.
   * 
   * @return The {@link VmMethod} that has been has been inserted into another
   *         method as part of this optimization.
   */
  VmMethod getInlinedMethod();

}
