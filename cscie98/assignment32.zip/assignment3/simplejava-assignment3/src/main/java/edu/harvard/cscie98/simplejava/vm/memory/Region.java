package edu.harvard.cscie98.simplejava.vm.memory;

import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public interface Region {

  /**
   * Reset this region, allowing subsequent allocation requests to overwrite
   * previously allocated space.
   * <P>
   * Note that this method does not remove any objects that may currently exist
   * in the region.
   */
  void reset();

  /**
   * Assign a contiguous block of this region.
   * 
   * @param bytes
   *          The number of bytes to be allocated. The space actually allocated
   *          may be more than the value passed here, but will not be less.
   * @return A {@link HeapPointer} to the newly-allocated space, or
   *         {@link HeapPointer#NULL} if the object could not be allocated.
   * @throws RuntimeException
   *           If the allocation size is not greater than zero.
   */
  HeapPointer allocate(long bytes);

  /**
   * Test whether a heap pointer falls inside this region.
   * 
   * @param ptr
   *          the {@link HeapPointer} to test.
   * 
   * @return true if the pointer refers to a memory address inside this region,
   *         false if it refers to an address outside the region.
   */
  boolean pointerInRegion(HeapPointer ptr);
}
