package edu.harvard.cscie98.simplejava;

import java.util.HashSet;
import java.util.Set;

import edu.harvard.cscie98.simplejava.config.HeapParameters;
import edu.harvard.cscie98.simplejava.config.Log;
import edu.harvard.cscie98.simplejava.impl.classloader.DirectoryClassLoader;
import edu.harvard.cscie98.simplejava.impl.interpreter.SwitchInterpreter;
import edu.harvard.cscie98.simplejava.impl.jit.DynamicProfilerImpl;
import edu.harvard.cscie98.simplejava.impl.jit.JitCompilerImpl;
import edu.harvard.cscie98.simplejava.impl.memory.heap.HeapImpl;
import edu.harvard.cscie98.simplejava.impl.memory.memorymanager.SemiSpaceMemoryManager;
import edu.harvard.cscie98.simplejava.impl.objectmodel.ObjectBuilderImpl;
import edu.harvard.cscie98.simplejava.impl.threads.JvmThreadImpl;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeFactory;
import edu.harvard.cscie98.simplejava.vm.classloader.TypeName;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClass;
import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.execution.DynamicProfiler;
import edu.harvard.cscie98.simplejava.vm.execution.ExecutionException;
import edu.harvard.cscie98.simplejava.vm.execution.Interpreter;
import edu.harvard.cscie98.simplejava.vm.execution.JitCompiler;
import edu.harvard.cscie98.simplejava.vm.execution.UncaughtException;
import edu.harvard.cscie98.simplejava.vm.memory.Heap;
import edu.harvard.cscie98.simplejava.vm.memory.MemoryManager;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapObject;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectBuilder;
import edu.harvard.cscie98.simplejava.vm.objectmodel.ObjectHeader;
import edu.harvard.cscie98.simplejava.vm.threads.JvmThread;
import edu.harvard.cscie98.simplejava.vm.threads.StackFrame;

public class SimpleJavaVm {

  private static final String MAIN_METHOD_NAME = "main";
  private static final String MAIN_METHOD_SIGNATURE = "([Ljava/lang/String;)V";

  Interpreter interpreter;
  ObjectBuilder objectBuilder;
  VmClassLoader classLoader;
  DynamicProfiler profiler;
  JitCompiler jit;
  Heap heap;
  HeapParameters heapParams;
  JvmThread thread;
  MemoryManager memoryManager;
  StackFrame mainFrame;

  public static void main(final String[] args) {
    final CliOptions opts = parseCommandLine(args);
    final TypeName mainClass = opts.mainClass;
    final SimpleJavaVm vm = setupVm(opts);
    final UncaughtException exception = vm.runMainClass(args, mainClass);

    if (exception != null) {
      vm.printUncaughtException(exception);
    }
    vm.printOutputBuffer(vm.classLoader);
    vm.interpreter.printStats();
  }

  static SimpleJavaVm setupVm(final CliOptions opts, final Object... objects) {
    final SimpleJavaVm vm = new SimpleJavaVm();
    final String classPath = opts.classPath;
    final long heapSize = opts.maxHeap * HeapParameters.BYTES_IN_KB;
    for (final Log.Component component : opts.verbose) {
      Log.setVerbose(component);
    }

    vm.classLoader = createOrSub(VmClassLoader.class, new DirectoryClassLoader(classPath), objects);
    vm.profiler = createOrSub(DynamicProfiler.class, new DynamicProfilerImpl(), objects);
    final int threshold = opts.inline ? opts.jitThreshold : Integer.MAX_VALUE;
    vm.profiler.setCompilationThreshold(threshold);
    final JitCompiler jit = new JitCompilerImpl(vm.profiler, vm.classLoader);
    vm.jit = createOrSub(JitCompiler.class, jit, objects);
    vm.classLoader.setJitCompiler(vm.jit);

    vm.heap = createOrSub(Heap.class, new HeapImpl(), objects);
    vm.heapParams = createOrSub(HeapParameters.class, new HeapParameters(0x100000, heapSize,
        vm.heap), objects);

    vm.thread = createOrSub(JvmThread.class, new JvmThreadImpl(), objects);
    vm.objectBuilder = new ObjectBuilderImpl(vm.classLoader, (HeapImpl) vm.heap);
    final MemoryManager mm = new SemiSpaceMemoryManager(vm.heapParams, vm.thread, vm.objectBuilder,
        vm.classLoader);
    vm.memoryManager = createOrSub(MemoryManager.class, mm, objects);
    ((ObjectBuilderImpl) vm.objectBuilder).setMemoryManager(mm);

    vm.interpreter = new SwitchInterpreter(vm.classLoader, vm.thread, vm.objectBuilder, jit);
    vm.classLoader.setExecutionEngine(vm.interpreter);
    ((ObjectBuilderImpl) vm.objectBuilder).setInterpreter(vm.interpreter);
    return vm;
  }

  private static <T> T createOrSub(final Class<T> type, final T sub, final Object[] objects) {
    for (final Object obj : objects) {
      if (obj.getClass().isAssignableFrom(type)) {
        return type.cast(obj);
      }
    }
    return sub;
  }

  public UncaughtException runMainClass(final String[] args, final TypeName mainClass) {
    final VmClass cls = classLoader.loadClass(mainClass);
    final VmMethod mainMethod = cls.getMethod(MAIN_METHOD_NAME, MAIN_METHOD_SIGNATURE);
    if (mainMethod == null) {
      throw new ExecutionException("No main method in class " + mainClass);
    }
    final HeapPointer argArray = buildCommandLineArgArray(objectBuilder, args);
    try {
      mainFrame = interpreter.executeMethod(mainMethod, argArray);
    } catch (final UncaughtException e) {
      Log.exception("Uncaught Exception");
      return e;
    }
    Log.interpreter("Main Method Frame\n=================");
    Log.interpreter("" + mainFrame);
    return null;
  }

  private static HeapPointer buildCommandLineArgArray(final ObjectBuilder objectBuilder,
      final String[] args) {
    final TypeName stringType = TypeFactory.fromBinaryName("java.lang.String");
    final HeapObject array = objectBuilder.createArray(stringType, args.length);
    for (int i = 0; i < args.length; i++) {
      final HeapObject internString = objectBuilder.internString(args[i]);
      array.setValueAtOffset(i, internString.getAddress());
    }
    return array.getAddress();
  }

  private void printUncaughtException(final UncaughtException exception) {
    final HeapObject exObj = exception.getException().dereference();
    final VmClass cls = classLoader.loadClass(TypeFactory.fromBinaryName("java.lang.Throwable"));
    final VmMethod mthd = cls.getMethod("printStackTrace", "()V");
    interpreter.executeMethod(mthd, exception.getException());
  }

  public void printOutputBuffer(final VmClassLoader cl) {
    System.out.println("Run complete. Printing output buffer");
    System.out.println("====================================");
    final HeapObject bufferObj = getOutputBuffer();
    System.out.println("Standard Output\n===============");
    for (int i = 0; i < getOutputLength(bufferObj); i++) {
      final String line = getStringFromBuffer(bufferObj, i);
      if (line != null) {
        System.out.print(line);
      }
    }
  }

  public HeapObject getOutputBuffer() {
    final VmClass printStream = classLoader.loadClass(TypeFactory
        .fromBinaryName("java.io.PrintStream"));
    final Object bufferFld = printStream.getStaticField("buffer",
        TypeFactory.fromDescriptor("[Ljava/lang/String;"));
    return ((HeapPointer) bufferFld).dereference();
  }

  public int getOutputLength(final HeapObject bufferObj) {
    return (int) bufferObj.getHeader().getWord(ObjectHeader.ARRAY_LENGTH_WORD);
  }

  public int getNonNullOutputLength(final HeapObject bufferObj) {
    int count = 0;
    for (int i = 0; i < getOutputLength(bufferObj); i++) {
      final String line = getStringFromBuffer(bufferObj, i);
      if (line != null) {
        count++;
      }
    }
    return count;
  }

  public String getStringFromBuffer(final HeapObject bufferObj, final int idx) {
    final HeapPointer str = (HeapPointer) bufferObj.getValueAtOffset(idx);
    if (str != HeapPointer.NULL) {
      final HeapObject strObj = str.dereference();
      final HeapObject strBuff = ((HeapPointer) strObj.getValueAtOffset(0)).dereference();
      final int strLen = (int) strBuff.getHeader().getWord(ObjectHeader.ARRAY_LENGTH_WORD);
      final byte[] bytes = new byte[strLen];
      for (int j = 0; j < strLen; j++) {
        final byte bte = ((Integer) strBuff.getValueAtOffset(j)).byteValue();
        bytes[j] = bte;
      }
      return new String(bytes);
    }
    return null;
  }

  private static CliOptions parseCommandLine(final String[] args) {
    final CliOptions opts = new CliOptions();
    try {
      if (args.length < 2) {
        throw new RuntimeException();
      }
      opts.classPath = args[0];
      opts.mainClass = TypeFactory.fromBinaryName(args[1]);
      for (int i = 2; i < args.length; i++) {
        if (args[i].startsWith(CliOptions.MAX_HEAP)) {
          final String size = args[i].substring(CliOptions.MAX_HEAP.length());
          opts.maxHeap = Integer.parseInt(size);
        } else if (args[i].startsWith(CliOptions.JIT_THRESHOLD)) {
          final String threshold = args[i].substring(CliOptions.JIT_THRESHOLD.length());
          opts.jitThreshold = Integer.parseInt(threshold);
        } else {
          switch (args[i]) {
          case CliOptions.NO_INLINE:
            opts.inline = false;
            break;
          case CliOptions.VERBOSE_ALLOC:
            opts.verbose.add(Log.Component.Allocator);
            break;
          case CliOptions.VERBOSE_GC:
            opts.verbose.add(Log.Component.GC);
            break;
          case CliOptions.VERBOSE_CL:
            opts.verbose.add(Log.Component.ClassLoader);
            break;
          case CliOptions.VERBOSE_INTERPRET:
            opts.verbose.add(Log.Component.Interpreter);
            break;
          case CliOptions.VERBOSE_JIT:
            opts.verbose.add(Log.Component.JIT);
            break;
          case CliOptions.VERBOSE_INLINER:
            opts.verbose.add(Log.Component.Inliner);
            break;
          case CliOptions.VERBOSE_EXCEPTIONS:
            opts.verbose.add(Log.Component.Exceptions);
            break;
          case CliOptions.VERBOSE_STATS:
            opts.verbose.add(Log.Component.Stats);
            break;
          default:
            throw new RuntimeException();
          }
        }
      }
    } catch (final RuntimeException e) {
      printUsage();
      System.exit(1);
    }
    return opts;
  }

  private static void printUsage() {
    String usage = "The SimpleJavaVm requires two arguments:\n";
    usage += "    ClassPath:  A String containing the location of classes to be loaded by the SimpleJavaVM.\n";
    usage += "                Note that this does not include the location of the SimpleJavaVm itself or its dependencies/\n";
    usage += "                On Unix and OSX the paths are separated by the ':' character.\n";
    usage += "                On Windows the paths are separated by the ';' character.\n";
    usage += "    Main Class: The binary name of the main class (eg, edu.harvard.cscie98.sample_code.Empty).\n";
    usage += "The VM can also accept the following optional arguments:\n";
    usage += "    " + CliOptions.NO_INLINE + "Turn off inlining.\n";
    usage += "    " + CliOptions.MAX_HEAP + "<size>: The maximum heap size, in kb.\n";
    usage += "    " + CliOptions.JIT_THRESHOLD
        + " The number of times a method should be called before it can be JIT compiled.\n";
    usage += "    " + CliOptions.VERBOSE_ALLOC + ": Print verbose allocation details.\n";
    usage += "    " + CliOptions.VERBOSE_GC + ": Print verbose garbage collection details.\n";
    usage += "    " + CliOptions.VERBOSE_CL + ": Print verbose class loading details.\n";
    usage += "    " + CliOptions.VERBOSE_INTERPRET + ": Print verbose interpretation details.\n";
    usage += "    " + CliOptions.VERBOSE_JIT + ": Print verbose JIT compilation details.\n";
    usage += "    " + CliOptions.VERBOSE_INLINER + ": Print verbose inline algorithm details.\n";
    usage += "    " + CliOptions.VERBOSE_EXCEPTIONS
        + ": Print verbose exception handling details.\n";
    usage += "    " + CliOptions.VERBOSE_STATS + ": Print execution statistics.\n";
    System.out.println(usage);
  }
}

class CliOptions {

  static final String MAX_HEAP = "-maxHeap";
  static final String JIT_THRESHOLD = "-jitThreshold";
  static final String NO_INLINE = "-noInline";
  static final String VERBOSE_ALLOC = "-verboseAllocation";
  static final String VERBOSE_GC = "-verboseGC";
  static final String VERBOSE_CL = "-verboseClassLoading";
  static final String VERBOSE_INTERPRET = "-verboseInterpreter";
  static final String VERBOSE_JIT = "-verboseJIT";
  static final String VERBOSE_INLINER = "-verboseInliner";
  static final String VERBOSE_EXCEPTIONS = "-verboseExceptions";
  static final String VERBOSE_STATS = "-verboseStats";

  String classPath;
  TypeName mainClass;
  int maxHeap = 1024;
  int jitThreshold = 10;
  boolean inline = true;
  Set<Log.Component> verbose = new HashSet<Log.Component>();
}
