package edu.harvard.cscie98.simplejava.impl.interpreter;

import org.apache.bcel.Constants;
import org.junit.Before;

public class LdcBytecodeTest extends BytecodeTest {

  @Override
  @Before
  public void setUp() {
    super.setUp();

  }

  @Override
  protected int getMaxStack() {
    return -1;
  }

  @Override
  protected int getMaxLocals() {
    return -1;
  }

  @Override
  protected byte[] getBytes() {
    return new byte[] { (byte) Constants.LDC };
  }

}
