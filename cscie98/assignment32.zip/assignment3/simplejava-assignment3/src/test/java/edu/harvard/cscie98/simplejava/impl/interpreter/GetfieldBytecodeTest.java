package edu.harvard.cscie98.simplejava.impl.interpreter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.apache.bcel.Constants;
import org.junit.Before;
import org.junit.Test;

import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapObject;
import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public class GetfieldBytecodeTest extends BytecodeTest {

  private HeapPointer ref;
  private Object val;

  @Override
  @Before
  public void setUp() {
    super.setUp();
    val = new Object();
    ref = getRefWithFieldInCp(5);
    final HeapObject obj = ref.dereference();
    when(obj.getValueAtOffset(5)).thenReturn(val);
    frame.push(ref);
  }

  @Override
  protected int getMaxStack() {
    return 1;
  }

  @Override
  protected int getMaxLocals() {
    return 0;
  }

  @Override
  protected byte[] getBytes() {
    return new byte[] { (byte) Constants.GETFIELD, 00, 8 };
  }

  @Test
  public void testStackLayout() {
    interpreter.interpretBytecode(frame);
    assertEquals(1, frame.getStack().size());
    assertEquals(val, frame.pop());
  }

  @Test
  public void testProgramCounter() {
    interpreter.interpretBytecode(frame);
    assertEquals(3, frame.getProgramCounter());
  }

}
