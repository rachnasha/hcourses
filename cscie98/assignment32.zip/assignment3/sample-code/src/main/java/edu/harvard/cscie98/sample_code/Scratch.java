package edu.harvard.cscie98.sample_code;

public class Scratch {

  // Quick and easy place to try out your own code - put code in here, build,
  // inspect with javap and run it on the SimpleJava VM

}
