package edu.harvard.cscie98.sample_code;

public class UncaughtException {
  public static void main(final String[] args) {
    throw new RuntimeException();
  }
}
