package java.lang;

public class RuntimeException extends Throwable {

}
