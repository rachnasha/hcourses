package edu.harvard.cscie98.simplejava.vm.memory;

import edu.harvard.cscie98.simplejava.vm.objectmodel.HeapPointer;

public interface MemoryManager {

  /**
   * Assign a block of memory from the Java heap.
   * <P>
   * This method allocates memory according to the system's memory management
   * strategy. It does not initialize the contents of the memory, or assign any
   * object header information.
   * <P>
   * If there is insufficient memory in the region to which the memory manager
   * allocates, this method will trigger a garbage collection. After reclaiming
   * memory it will attempt to perform the allocation again. If, after
   * potentially multiple GC cycles, a block of the appropriate size cannot be
   * found, this method will return {@link HeapPointer#NULL}.
   * 
   * @param size
   *          The number of bytes to allocate. This must be greater than zero.
   * @return A chunk of memory with a size greater than or equal to the number
   *         of bytes requested, or {@link HeapPointer#NULL} if no memory is
   *         available.
   */
  HeapPointer allocate(long size);

}
