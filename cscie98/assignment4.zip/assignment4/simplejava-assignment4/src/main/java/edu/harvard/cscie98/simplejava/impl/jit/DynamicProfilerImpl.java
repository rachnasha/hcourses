package edu.harvard.cscie98.simplejava.impl.jit;

import java.util.HashSet;
import java.util.Set;

import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;
import edu.harvard.cscie98.simplejava.vm.execution.DynamicProfiler;
import edu.harvard.cscie98.simplejava.vm.execution.InlineOptimization;

public class DynamicProfilerImpl implements DynamicProfiler {

  public DynamicProfilerImpl() {
  }

  @Override
  public void methodCalled(final VmMethod mthd) {
  }

  @Override
  public boolean shouldCompileMethod(final VmMethod mthd) {
    return false;
  }

  @Override
  public void methodCompiled(final VmMethod mthd, final Set<InlineOptimization> optimizations) {
  }

  @Override
  public void analyzeClassHierarchy(final VmClassLoader classLoader) {
  }

  @Override
  public Set<VmMethod> getMethodsWithInvalidOptimizations() {
    final Set<VmMethod> invalid = new HashSet<VmMethod>();
    return invalid;
  }

  @Override
  public boolean canInline(final VmMethod mthd) {
    return false;
  }

  @Override
  public void setCompilationThreshold(final int threshold) {
  }
}
