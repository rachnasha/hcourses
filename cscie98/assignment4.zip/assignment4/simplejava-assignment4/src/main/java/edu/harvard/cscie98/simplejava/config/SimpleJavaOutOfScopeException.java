package edu.harvard.cscie98.simplejava.config;

public class SimpleJavaOutOfScopeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public SimpleJavaOutOfScopeException(final String msg) {
    super(msg);
  }

}
