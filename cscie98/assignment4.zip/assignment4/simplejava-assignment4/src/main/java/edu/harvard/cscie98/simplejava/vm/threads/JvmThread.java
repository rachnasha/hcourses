package edu.harvard.cscie98.simplejava.vm.threads;

public interface JvmThread {

  /**
   * Get the execution stack for this thread.
   * 
   * @return The {@link JvmStack} associated with this thread.
   */
  JvmStack getStack();

  /**
   * Resume execution by this thread after it has been paused.
   * 
   * @throws RuntimeException
   *           if the thread is not currently paused.
   */
  public void resume();

  /**
   * Pause this thread temporarily.
   * <P>
   * This method ensures that the thread has reached a GC safe point before
   * suspending.
   * 
   * @throws RuntimeException
   *           if the thread is already paused.
   */
  public void pause();

}
