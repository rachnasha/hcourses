package edu.harvard.cscie98.simplejava.vm.classloader;

public interface CodeGenerator {

  VmMethod generatePrimordialMethod(TypeName mainClass, String mainMethodName,
      String mainMethodSignature);

  VmMethod generateClinitPrimordialMethod(TypeName cls);

}
