package edu.harvard.cscie98.simplejava.vm.execution;

import java.util.Set;

import edu.harvard.cscie98.simplejava.vm.classloader.VmClassLoader;
import edu.harvard.cscie98.simplejava.vm.classloader.VmMethod;

public interface DynamicProfiler {

  /**
   * Notify the profiler that a method has been invoked.
   * 
   * This method is called before the interpreter executes the first instruction
   * of the new method. It is called for every InvokeStatic, InvokeVirtual and
   * InvokeSpecial instruction that the interpreter executes.
   * 
   * This method is used to gather statistics and is assumed to add only a small
   * performance overhead. In particular, it does not trigger compilation.
   * 
   * @param mthd
   *          The {@link VmMethod} that represents the method being called.
   */
  void methodCalled(VmMethod mthd);

  /**
   * Configure the number of invocations required for a given method before it
   * is a candidate for compilation.
   * 
   * This method sets the threshold at which a method should be compiled (see
   * the description for {@link DynamicProfiler#shouldCompileMethod(VmMethod)}).
   * This method is guaranteed to be called at least once before the interpreter
   * begins to execute the program.
   * 
   * If it is called during program execution, the updated threshold will not
   * affect compilation decisions that have already been made (i.e. lowering the
   * threshold will not force methods to compile before they are next considered
   * by {@code shouldCompileMethod}).
   * 
   * This method should not perform any compilation.
   * 
   * @param threshold
   *          the new value for the number of times a method should be called
   *          before it is considered a candidate for compilation.
   */
  void setCompilationThreshold(int threshold);

  /**
   * Determine whether a given method should be compiled based on the program's
   * execution so far.
   * 
   * In SimpleJava, JIT compilation is based on the number of times a method has
   * been called. The compilation threshold is set by the argument to
   * {@link DynamicProfiler#setCompilationThreshold(int)}. If a method has been
   * called at least that many times, it is a candidate for compilation.
   * 
   * This method simply determines whether a {@link VmMethod} should be compiled
   * or not. It does not implement the compilation itself.
   * 
   * @param mthd
   *          the {@code VmMethod} that may be a candidate for compilation.
   * 
   * @return True if the method should be compiled, false if it should not.
   */
  boolean shouldCompileMethod(VmMethod mthd);

  /**
   * Notification to the profiler that a method has been compiled.
   * 
   * This method is called once the JIT compiler has completed compilation of a
   * method. It informs the profiler that compilation has occurred, and it
   * provides a list of optimizations performed during the compilation pass.
   * 
   * @param mthd
   *          The {@link VmMethod} that has been compiled.
   * 
   * @param optimizations
   *          A {@code Set} of {@link InlineOptimization} instances that
   *          indicate which optimizations were applied to the method.
   */
  void methodCompiled(VmMethod mthd, Set<InlineOptimization> optimizations);

  /**
   * Perform Class Hierarchy Analysis (CHA) across all loaded classes.
   * 
   * This method is called every time a class is loaded by the class loader. It
   * inspects the set of classes loaded by the class loader to determine what
   * optimizations are valid (see the definition of
   * {@link DynamicProfiler#canInline(VmMethod)} for the criteria that must be
   * met before a method can be inlined).
   * 
   * This method builds any data structures that will be required by subsequent
   * calls to {@code canInline}. It is expected to be a heavy-weight operation
   * and so will be called infrequently. Implementations of this method may
   * involve significant computation, particularly for large class hierarchies.
   * 
   * @param classLoader
   *          the {@link VmClassLoader} instance that has loaded a new class.
   */
  void analyzeClassHierarchy(final VmClassLoader classLoader);

  /**
   * Determine which compiled methods are no longer valid after a class has been
   * loaded.
   * 
   * This method is called after a new Class Hierarchy Analysis has been
   * performed by {@link DynamicProfiler#analyzeClassHierarchy(VmClassLoader)}.
   * It is guaranteed that {@code analyzeClassHierarchy} has been called at
   * least once before this method is called.
   * 
   * This method checks all optimizations that have been performed while
   * compiling methods so far in the VM's execution to determine whether changes
   * to the CHA have rendered them invalid.
   * 
   * A compiled method is considered to be invalid if:
   * <ul>
   * <li>It contains an inlined method that can no longer be safely inlined (see
   * the definition of {@link DynamicProfiler#canInline(VmMethod)} for the
   * criteria under which a method can be inlined).
   * <li>It contains an inlined method that has been determined to be invalid.
   * </ul>
   * 
   * Methods that contain invalid optimizations will be deoptimized, and may be
   * recompiled.
   * 
   * This method may perform significant computation work to determine which
   * methods are invalid. It should be called infrequently.
   * 
   * @return A {@code Set} of {@link VmMethod} objects that contains all methods
   *         that have been found to be invalid. This set may be empty if no
   *         methods are invalid.
   */
  Set<VmMethod> getMethodsWithInvalidOptimizations();

  /**
   * Determine whether a given method can be inlined.
   * 
   * This method uses the results of the Class Hierarchy Analysis performed in
   * {@link DynamicProfiler#analyzeClassHierarchy(VmClassLoader)} to decide
   * whether a method is suitable for inlining.
   * 
   * Inlining decisions are made globally, i.e. they concern only the
   * characteristics of the method to be inlined, not the call site where the
   * inlining will occur. This means that some inlining opportunities may be
   * missed if a more complex analysis were to show that a specific call site
   * was monomorphic.
   * 
   * A method may be inlined if:
   * <ul>
   * <li>It is a constructor.
   * <li>It is static.
   * <li>It is not overridden by any subclass that has been loaded into the VM.
   * </ul>
   * 
   * This method is expected to be called frequently, and so should not perform
   * significant computation.
   * 
   * @param mthd
   *          the {@link VmMethod} that may or may not be inlined.
   * @return True if the method can be inlined, false if it cannot.
   */
  boolean canInline(VmMethod mthd);

}
