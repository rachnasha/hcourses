package java.lang;

public class ArrayIndexOutOfBoundsException extends RuntimeException {

}
