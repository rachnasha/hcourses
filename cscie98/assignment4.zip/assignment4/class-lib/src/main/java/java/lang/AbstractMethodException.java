package java.lang;

public class AbstractMethodException extends RuntimeException {

}
