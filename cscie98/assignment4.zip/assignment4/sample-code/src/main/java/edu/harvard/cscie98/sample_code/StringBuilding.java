package edu.harvard.cscie98.sample_code;

public class StringBuilding {
  public static void main(final String[] args) {
    for (int i = 0; i < 10; i++) {
      System.out.println("Number: " + i);
    }
  }
}
